﻿using System.ComponentModel.DataAnnotations;

namespace BiteBliss.Models
{
    public class FoodViewModel
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public decimal Price { get; set; }
        [Required]
        public string Description { get; set; }

        [Required]
        public string ImagePath { get; set; }
    }
}
