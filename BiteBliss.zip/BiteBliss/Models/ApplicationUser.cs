﻿using Microsoft.AspNetCore.Identity;

namespace BiteBliss.Models
{
    public class ApplicationUser:IdentityUser
    {
        public string UserLocation { get; set; }
        public DateTime UserDate { get; set; }
    }
}
