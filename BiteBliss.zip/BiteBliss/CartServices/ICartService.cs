﻿
namespace BiteBliss.CartServices
{
    public interface ICartService
    {
        void AddToCart(int productId, string productName, decimal productPrice, int quantity, string type);
        List<CartItem> GetCartItems();
        // Add more methods as needed
    }

    public class CartItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public string Type { get; set; }
    }
}
