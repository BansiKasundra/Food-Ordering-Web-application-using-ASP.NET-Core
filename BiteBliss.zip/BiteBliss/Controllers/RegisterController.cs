﻿using Azure.Identity;
using BiteBliss.Data;
using BiteBliss.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;

namespace BiteBliss.Controllers
{
    public class RegisterController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly ILogger<RegisterController> _logger; // Add ILogger


        public RegisterController(ApplicationDbContext db,UserManager<ApplicationUser>userManager,SignInManager<ApplicationUser>signInManager, ILogger<RegisterController> logger)
        {
            _db = db;
            _userManager = userManager;
            _signInManager = signInManager;
            _logger = logger;

        }

        [HttpGet]
        public IActionResult UserLogin()
        {
            // Retrieve data if needed
            return View() ;
        }

        [HttpPost]
        public async Task<IActionResult> UserLogin(Registers login)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var result = await _signInManager.PasswordSignInAsync(login.UserName, login.UserPassword, false, false);

                    if (result.Succeeded)
                    {
                        // Log successful login
                        _logger.LogInformation($"User {login.UserName} logged in successfully.");
                        return RedirectToAction("Index", "Home");
                    }

                    if (result.IsLockedOut)
                    {
                        // Log account lockout
                        _logger.LogWarning($"Account for {login.UserName} is locked out.");
                        ModelState.AddModelError("", "Account locked out.");
                    }
                    else
                    {
                        // Log invalid login attempt
                        _logger.LogWarning($"Invalid login attempt for user {login.UserName}.");
                        ModelState.AddModelError("", "Invalid login attempt.");
                    }
                }
                else
                {
                    // Log model state errors
                    _logger.LogError("Model state is not valid.");
                }
            }
            catch (Exception ex)
            {
                // Log unexpected exception
                _logger.LogError($"An unexpected error occurred: {ex.Message}");
                ModelState.AddModelError("", "An unexpected error occurred. Please try again.");
            }

            // If the model state is not valid or login fails, return the user to the login page with validation errors
            return View(login);
        }


        [HttpGet]
        public IActionResult UserRegister()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UserRegister(Registers newUser)
        {
            if (ModelState.IsValid)
            {
             
                // If the model is valid, add the new user to the database
                _db.users.Add(newUser);
                
                _db.SaveChanges();

                return RedirectToAction("UserLogin");
            }

            // If the model is not valid, return the user to the registration page with validation errors
            return View(newUser);
        }
    }
}
