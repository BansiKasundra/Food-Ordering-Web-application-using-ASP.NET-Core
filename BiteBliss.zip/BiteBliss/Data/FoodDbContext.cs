﻿using BiteBliss.Models;
using Microsoft.EntityFrameworkCore;

namespace BiteBliss.Data
{
    public class FoodDbContext:DbContext
    {

        public FoodDbContext()     //ctor shortcut for this constructor
        {

        }

        public FoodDbContext(DbContextOptions<FoodDbContext> o) : base(o)
        {
        }

        public DbSet<FoodDataModel> FoodData { get; set; }
        public DbSet<AddToCartModel> AddToCart { get; set; }

        //public DbSet<FoodItemDataModel> FoodItemData { get; set; }

    }
}
